import React from 'react';

function FalsePage() {
    return (
        <h1>Error 404, there is no page with the current provided url</h1>
    );
}

export default FalsePage;